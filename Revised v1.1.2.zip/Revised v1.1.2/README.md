<h1>Bitcoin News Browser Extension<h1>

#### Status: Developing ⚠️

<div align="center">
	<img width=600px src="./assets/extension.gif">
</div><br>

#### This extension provides real-time information on Bitcoin price, days remaining until the halving event, and NUPL (Net Unrealized Profit/Loss). It also includes recent news posts on topics such as Wall Street's interest in Bitcoin ETF filing, the safety of nuclear energy, and the viability of Bitcoin mining in oil and gas well sites.

## Features
+ 

## Installation
To install the extension, follow these steps:
1. Clone or download the repository
2. Open your Chrome browser and go to chrome://extensions
3. Toggle the "Developer mode" button in the top right corner
4. Click on the "Load unpacked" button and select the extension folder

## How to Use


## Contributing


## License
This project is licensed under the MIT License - see the LICENSE.md file for details.

## Credits
This application was created by [Julio Nascimento](https://www.linkedin.com/in/julio-spnascimento/).